<?php
$theme = array();
$theme['admin'] = true;
$theme['client'] = true;
$theme['lsr'] = true;
$theme['driver'] = true;