<?php
class Models_Company2 extends Model
{
    public static $_table = 'sys_companies2';
}
