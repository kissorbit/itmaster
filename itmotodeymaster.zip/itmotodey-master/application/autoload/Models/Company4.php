<?php
class Models_Company4 extends Model
{
    public static $_table = 'sys_companies4';
}
