<?php
class Models_User extends Model
{
    public static $_table = 'sys_users';
}
