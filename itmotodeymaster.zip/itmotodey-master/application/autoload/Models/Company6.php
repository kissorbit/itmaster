<?php
class Models_Company6 extends Model
{
    public static $_table = 'sys_companies6';
}
