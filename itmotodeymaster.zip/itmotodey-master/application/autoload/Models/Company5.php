<?php
class Models_Company5 extends Model
{
    public static $_table = 'sys_companies5';
}
