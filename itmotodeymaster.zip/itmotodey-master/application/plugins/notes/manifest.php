<?php
$plugin = array();
$plugin['name'] = 'Note';
$plugin['author'] = 'Your Name';
$plugin['version'] = '1.0.0';
$plugin['description'] = 'Sample Plugin for iBilling';
$plugin['url'] = 'http://www.ibilling.io/plugin-development/';