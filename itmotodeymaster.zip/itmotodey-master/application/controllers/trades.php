<?php

_auth();
$ui->assign('_application_menu', 'trades');
$ui->assign('_title', $_L['Trades'] . '- ' . $config['CompanyName']);
$ui->assign('_st', $_L['Trades']);
$action = $routes['1'];
$user = User::_info();
$ui->assign('user', $user);

Event::trigger('trades');

switch ($action) {

    case 'new-lsps-offer':
        Event::trigger('trades/new-lsps-offer');

        $msg = '';

        $subject = _post('subject');
        $recipients = $_POST['recipients'];
        $content = _post('content');
        $notifyBySms = _post('sms');
        $file = $_FILES['file'];

        die(json_encode($file));
        echo $recipients;

        if ($subject == '') {
            $msg .= 'The subject cannot be empty<br>';
        }
        if ($content == '') {
            $msg .= 'The content cannot be empty<br>';
        }

        if ($msg != '') {
            echo $msg;
        }

        //die($subject);

        break;
    case 'list':

        $mode_css = '';
        $mode_js = '';

        $mode_css = Asset::css('footable/css/footable.core.min');

        $action2 = $routes['2'];

        switch ($action2) {
            case 'submit-lsr':
                $action3 = route(3);

                switch ($action3) {
                    case 'show':
                        $tradeId = route(4);
                        $trade = ORM::for_table('sys_companies6')->find_one($tradeId);
                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('submitLsr', $trade);
                        $ui->assign('lsps', $lsps);

                        $ui->assign('xheader', Asset::css([
                            'modal',
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'js/handlebars.min',
                                'js/list.min',
                                'trades/main',
                                'trades/trade',
                                'trades/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->assign('submitLsrTrades', $trade);

                        $ui->display('trades_list_submit_lsr_show.tpl');
                        break;

                    default:
                        $submitLsrTrades = ORM::for_table('sys_companies6')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.bill_lading_file_token)', 'bill_lading_file_id')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign('xheader', Asset::css(['modal']));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'modal',
                                'tinymce/tinymce.min',
                                'js/editor',
                                'numeric',
                                'trades/list/submit_lsr',
                            ])
                        );

                        $ui->assign('submitLsrTrades', $submitLsrTrades);

                        $ui->display('trades_list_submit_lsr.tpl');
                        break;
                }
                break;

            case 'transport-goods':
                $ui->display('trades_list_transport_goods.tpl');
                break;
            case 'rental-heavy-machine':
                $ui->display('trades_list_rental_heavy_machine.tpl');
                break;
            case 'purchase-material-construction':
                $ui->display('trades_list_purchase_material_construction.tpl');
                break;

            default:

                $mode_js = Asset::js([
                    'footable/js/footable.all.min',
                    'numeric',
                    'trades/list',
                ]);


                $submitLsrCount                    = ORM::for_table('sys_companies6')->count();
                $transportGoodsCount               = ORM::for_table('sys_companies1')->count();
                $rentalHeavyMachineCount           = ORM::for_table('sys_companies2')->count();
                $purchaseMaterialConstructionCount = ORM::for_table('sys_companies')->count();
                $purchasePackagingMaterialCount    = ORM::for_table('sys_companies4')->count();

                $ui->assign('submitLsrCount', $submitLsrCount);
                $ui->assign('transportGoodsCount', $transportGoodsCount);
                $ui->assign('rentalHeavyMachineCount', $rentalHeavyMachineCount);
                $ui->assign('purchaseMaterialConstructionCount', $purchaseMaterialConstructionCount);
                $ui->assign('purchasePackagingMaterialCount', $purchasePackagingMaterialCount);
                $ui->assign('xheader', $mode_css);
                $ui->assign('xfooter', $mode_js);

                $xjq =
                    '

    $(\'.amount\').autoNumeric(\'init\', {

    aSign: \'' .
                    $config['currency_code'] .
                    ' \',
    dGroup: ' .
                    $config['thousand_separator_placement'] .
                    ',
    aPad: ' .
                    $config['currency_decimal_digits'] .
                    ',
    pSign: \'' .
                    $config['currency_symbol_position'] .
                    '\',
    aDec: \'' .
                    $config['dec_point'] .
                    '\',
    aSep: \'' .
                    $config['thousands_sep'] .
                    '\'

    });

 ';

                $ui->assign('xjq', $xjq);

                $ui->display('trades_overview.tpl');
                break;
        }


        break;
    default:
        echo 'action not defined';
}
