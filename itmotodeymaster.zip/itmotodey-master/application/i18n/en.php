<?php
/*
 *
 * This File is located in- /application/18n/
Editing this file will be replaced when update. If you improve this file or need your localized file, edit below send the file to admin@cloudonex.com
*/

$_L['Login'] = 'Login';
$_L['Edit'] = 'Edit';
$_L['Delete'] = 'Delete';
$_L['Account'] = 'Account';
$_L['Date'] = 'Date';
$_L['Financial_Balances'] = 'Financial Balances';
$_L['Add_New_Account'] = 'Add New Account';
$_L['Manage_Accounts'] = 'Manage Accounts';
$_L['initial_balance'] = 'Initial Balance';
$_L['account_created_successfully'] = 'Account Created Successfully';
$_L['account_updated_successfully'] = 'Account Updated Successfully';
$_L['account_already_exist'] = 'Account Already Exist';
$_L['system'] = 'System';
$_L['Total'] = 'Total';
$_L['Account_Not_Found'] = 'Account Not Found';
$_L['ref_help'] = 'e.g. Transaction ID, Check No.';
$_L['amount_error'] = 'Invalid Amount';
$_L['Cleared'] = 'Cleared';
$_L['Uncleared'] = 'Uncleared';
$_L['Reconciled'] = 'Reconciled';
$_L['Void'] = 'Void';
$_L['Add_Deposit'] = 'Add Deposit';
$_L['Amount'] = 'Amount';
$_L['Payer'] = 'Payer';
$_L['Category'] = 'Category';
$_L['Payment Method'] = 'Payment Method';
$_L['Ref'] = 'Ref';
$_L['Status'] = 'Status';
$_L['Uncategorized'] = 'Uncategorized';
$_L['transaction_added_successfully'] = 'Transaction Added Successfully';
$_L['Add_Expense'] = 'Add Expense';
$_L['Payee'] = 'Payee';
$_L['description_error'] = 'A valid description is Required';
$_L['Transfer'] = 'Transfer';
$_L['From'] = 'From';
$_L['To'] = 'To';
$_L['Select An Account'] = 'Select An Account';
$_L['same_account_error'] = 'You can not Transfer between same account';
$_L['Transaction_Not_Found'] = 'Transaction Not Found';
$_L['transaction_delete_successful'] = 'Transaction Deleted Successfully';
$_L['account_delete_successful'] = 'Account Deleted Successfully';
$_L['transaction_update_successful'] = 'Transaction Udated Successfully';
$_L['Number_of_Payment'] = 'Number of Payment';
$_L['Frequency'] = 'Frequency';
$_L['Monthly'] = 'Monthly';
$_L['Weekly'] = 'Weekly';
$_L['Bi_Weekly'] = 'Bi Weekly';
$_L['Everyday'] = 'Everyday';
$_L['Every_30_Days'] = 'Every 30 Days';
$_L['Every_2_Month'] = 'Every 2 Month';
$_L['Quarterly'] = 'Quarterly';
$_L['Every_6_Month'] = 'Every 6 Month';
$_L['Yearly'] = 'Yearly';
$_L['Once_Only'] = 'Once Only';
$_L['Edit_Option'] = 'Edit Option';
$_L['Edit_Single_Occurrence'] = 'Edit Single Occurrence';
$_L['Delete_Single_Occurrence'] = 'Delete Single Occurrence';
$_L['Edit_All_Occurrence'] = 'Edit All Occurrence';
$_L['Delete_All_Occurrence'] = 'Delete All Occurrence';
$_L['Manage'] = 'Manage';
$_L['Confirm'] = 'Confirm';
$_L['Enter_Transaction'] = 'Enter Transaction';
$_L['Payment_Cleared'] = 'Payment Cleared';
$_L['an_error_occured'] = 'An Error Occured';
$_L['name_exist_error'] = 'Name already exist';
$_L['account_title_length_error'] =
    'Account Title Should Be within 3 to 100 character';
$_L['tr_delete_warning'] =
    'Deleting Transaction can not be undone. Current Balance with associated account will be adjusted. ';
$_L['frequency_error'] = 'Invalid Frequency or Number of Payment';
$_L['name_error'] = 'Name is Required';
$_L['edit_successful'] = 'Edited Successfully';
$_L['added_successful'] = 'Added Successfully';
$_L['delete_successful'] = 'Deleted Successfully';
$_L['Name'] = 'Name';
$_L['Account_Title'] = 'Account Title';
$_L['Edit_Account'] = 'Edit Account';
$_L['Description'] = 'Description';
$_L['Submit'] = 'Submit';
$_L['Transaction'] = 'Transaction';
$_L['Add_Repeating_Income'] = 'Add Repeating Income';
$_L['Repeating_Income'] = 'Repeating Income';
$_L['Repeating_Expense'] = 'Repeating Expense';
$_L['Add_Repeating_Expense'] = 'Add Repeating Expense';
$_L['frequency_help'] =
    'e.g. If you choose Frequency Monthly, You can put Number of Payment 12. That will repeat transaction for next 12 months.';
$_L['Welcome'] = 'Welcome';
$_L['Type'] = 'Type';
$_L['View'] = 'View';
$_L['Income'] = 'Income';
$_L['Expense'] = 'Expense';
$_L['Credit'] = 'Credit';
$_L['Debit'] = 'Debit';
$_L['Cancel'] = 'Cancel';
$_L['Password'] = 'Password';
$_L['Dr'] = 'Dr';
$_L['Cr'] = 'Cr';
$_L['Method'] = 'Method';
$_L['frequency_error'] = 'Invalid Frequency';
$_L['Toggle_navigation'] = 'Toggle navigation';
$_L['MoneyFlow'] = 'MoneyFlow';
$_L['Dashboard'] = 'Dashboard';
$_L['Accounts'] = 'Accounts';
$_L['Account_Balances'] = 'Account Balances';
$_L['Ad_An_Account'] = 'Ad An Account';
$_L['Transactions'] = 'Transactions';
$_L['View_Transactions'] = 'View Transactions';
$_L['Recurring'] = 'Recurring';
$_L['Income_Calendar'] = 'Income Calendar';
$_L['Expense_Calendar'] = 'Expense Calendar';
$_L['Reports'] = 'Reports';
$_L['Account_Statement'] = 'Account Statement';
$_L['Reports_by_Date'] = 'Reports by Date';
$_L['Income_Reports'] = 'Income Reports';
$_L['Expense_Reports'] = 'Expense Reports';
$_L['Income_Vs_Expense'] = 'Income Vs Expense';
$_L['Settings'] = 'Settings';
$_L['Expense_Categories'] = 'Expense Categories';
$_L['Income_Categories'] = 'Income Categories';
$_L['Payees'] = 'Payees';
$_L['Payers'] = 'Payers';
$_L['Payment_Methods'] = 'Payment Methods';
$_L['Users'] = 'Users';
$_L['Application_Settings'] = 'Application Settings';
$_L['My_Account'] = 'My Account';
$_L['Edit_Profile'] = 'Edit Profile';
$_L['Change_Password'] = 'Change Password';
$_L['Logout'] = 'Logout';
$_L['Income_Today'] = 'Income Today';
$_L['Expense_Today'] = 'Expense Today';
$_L['Income_This_Month'] = 'Income This Month';
$_L['Expense_This_Month'] = 'Expense This Month';
$_L['Latest_5_Income'] = 'Latest 5 Income';
$_L['Latest_5_Expense'] = 'Latest 5 Expense';
$_L['Income_Graph_This_Year'] = 'Income Graph This Year';
$_L['Expense_Graph_This_Year'] = 'Expense Graph This Year';
$_L['Balance'] = 'Balance';
$_L['Next'] = 'Next';
$_L['Last'] = 'Last';
$_L['Latest_Expense'] = 'Latest Expense';
$_L['Budgets'] = 'Budgets';
$_L['View_Budgets'] = 'View Budgets';
$_L['Set_Budgets'] = 'Set Budgets';
$_L['Add_Payment_Method'] = 'Add Payment Method';
$_L['Manage_Payment_Methods'] = 'Manage Payment Methods';
$_L['drag_drop_edit'] =
    'Drag and drop the Items below for Repositioning. Click to Edit.';
$_L['Manage_Categories'] = 'Manage Categories';
$_L['Manage_Payees'] = 'Manage Payees';
$_L['Add_Payee'] = 'Add Payee';
$_L['Add_Payer'] = 'Add Payer';
$_L['Manage_Payers'] = 'Manage Payers';
$_L['Reports_Categories'] = 'Reports by Categories';
$_L['Reports_Payees'] = 'Reports by Payees';
$_L['Reports_Payers'] = 'Reports by Payers';
$_L['App_Name'] = 'Application Name/ Company Name';
$_L['App_Name_Help_Text'] = 'This Name will be shown on the Title';
$_L['Dark'] = 'Dark';
$_L['Blue'] = 'Blue';
$_L['Timezone'] = 'Timezone';
$_L['Decimal_Point'] = 'Decimal Point';
$_L['Thousands_Separator'] = 'Thousands Separator';
$_L['Currency_Code'] = 'Currency Code';
$_L['Edit_Categories'] = 'Edit Categories';
$_L['cat_del_help_txt'] =
    'Deleting Categories will rename all transactions under this category to Uncategorized ';
$_L['Current_Password'] = 'Current Password';
$_L['New_Password'] = 'New Password';
$_L['Confirm_New_Password'] = 'Confirm New Password';
$_L['Edit_Payee'] = 'Edit Payee';
$_L['Edit_Payer'] = 'Edit Payer';
$_L['Edit_Payment_Methods'] = 'Edit Payment Methods';
$_L['Statement'] = 'Statement';
$_L['Total_Income'] = 'Total Income';
$_L['Total_Expense'] = 'Total Expense';
$_L['All_Transactions_at_Date'] = 'All Transactions at Date';
$_L['Income_Summary'] = 'Income Summary';
$_L['Total_Income_This_Month'] = 'Total Income This Month';
$_L['Total_Income_This_Week'] = 'Total Income This Week';
$_L['Total_Income_Last_30_days'] = 'Total Income Last 30 days';
$_L['Last_20_deposit_Income'] = 'Last 20 deposit/ Income';
$_L['Monthly_Income_Graph'] = 'Monthly Income Graph';
$_L['Expense_Summary'] = 'Expense Summary';
$_L['Total Expense'] = 'Total Expense';
$_L['Total_Expense_This_Month'] = 'Total Expense This Month';
$_L['Total_Expense_This_Week'] = 'Total Expense This Week';
$_L['Total_Expense_Last_30_days'] = 'Total Expense Last 30 days';
$_L['Last_20_Expense'] = 'Last 20 Expense';
$_L['Monthly_Expense_Graph'] = 'Monthly Expense Graph';
$_L['Income_Vs_Expense_This_Year'] = 'Income Vs Expense This Year';
$_L['View_Statement'] = 'View Statement';
$_L['All_Transactions'] = 'All Transactions';
$_L['Select_Payer'] = 'Select Payer';
$_L['From_Date'] = 'From Date';
$_L['To_Date'] = 'To Date';
$_L['Select_Payee'] = 'Select Payee';
$_L['Export_for_Print'] = 'Export for Print';
$_L['Export_to_PDF'] = 'Export to PDF';
$_L['Manage_Users'] = 'Users';
$_L['Add_New_User'] = 'Add New User';
$_L['Username'] = 'Username';
$_L['Full_Name'] = 'Full Name';
$_L['user_type_help'] =
    'Choose User Type Employee to disable access to Settings';
$_L['Confirm_Password'] = 'Confirm Password';
$_L['User_Type'] = 'User Type';
$_L['Full_Administrator'] = 'Full Administrator';
$_L['Employee'] = 'Employee';
$_L['password_change_help'] = 'Keep Blank to do not change Password';
$_L['Edit_User'] = 'Edit User';
$_L['currency_help'] = 'Keep it blank if you do not want to show currency code';
$_L['Theme_Style'] = 'Theme Style';
$_L['Theme_Color'] = 'Theme Color';
$_L['Default_Language'] = 'Default Language';
$_L['CRM'] = 'CRM';

// log services providers =customer  log service requestors=customer1
$_L['Add Contact'] = 'Add Contact';
$_L['Add Customer'] = 'Add LSP';
$_L['Add Customer1'] = 'Add LSR';

$_L['List Contacts'] = 'List Contacts';
$_L['List Customers'] = 'List LSP';
$_L['List Customers1'] = 'List LSR';
$_L['New Deposit'] = 'New Deposit';
$_L['New Expense'] = 'New Expense';
$_L['View Transactions'] = 'View Transactions';
$_L['Balance Sheet'] = 'Balance Sheet';
$_L['Sales'] = 'Sales';
$_L['Invoices'] = 'Invoices';
$_L['New Invoice'] = 'New Invoice';
$_L['Recurring Invoices'] = 'Recurring Invoices';
$_L['New Recurring Invoice'] = 'New Recurring Invoice';
$_L['Bank n Cash'] = 'Bank & Cash';
$_L['New Account'] = 'New Account';
$_L['List Accounts'] = 'List Accounts';
$_L['Products n Services'] = 'Products & Services';
$_L['Products'] = 'Products';
$_L['New Product'] = 'New Product';
$_L['Services'] = 'Services';
$_L['New Service'] = 'New Service';
$_L['Account Statement'] = 'Account Statement';
$_L['Reports by Date'] = 'Reports by Date';
$_L['Income Reports'] = 'Income Reports';
$_L['Expense Reports'] = 'Expense Reports';
$_L['Income Vs Expense'] = 'Income Vs Expense';
$_L['All Income'] = 'All Income';
$_L['All Expense'] = 'All Expense';
$_L['All Transactions'] = 'All Transactions';
$_L['Utilities'] = 'Utilities';
$_L['Activity Log'] = 'Activity Log';
$_L['Email Message Log'] = 'Email Message Log';
$_L['Database Status'] = 'Database Status';
$_L['My Account'] = 'My Account';
$_L['Edit Profile'] = 'Edit Profile';
$_L['Change Password'] = 'Change Password';
$_L['General Settings'] = 'General Settings';
$_L['Localisation'] = 'Localization';
$_L['Manage Users'] = 'Administrator Users';
$_L['Payment Gateways'] = 'Payment Gateways';
$_L['Expense Categories'] = 'Expense Categories';
$_L['Income Categories'] = 'Income Categories';
$_L['Manage Tags'] = 'Manage Tags';
$_L['Payment Methods'] = 'Payment Methods';
$_L['Sales Taxes'] = 'Sales Taxes';
$_L['Email Settings'] = 'Email Settings';
$_L['Email Templates'] = 'Email Templates';
$_L['Automation Settings'] = 'Automation Settings';
$_L['Please Wait'] = 'Please Wait';
$_L['Search Customers'] = 'Search Customers';
$_L['Income Today'] = 'Log service provider today';
$_L['Income Today1'] = 'Log service Requestor today';
$_L['Income Today2'] = 'Drivers today';
$_L['Expense Today'] = 'Expense Today';
$_L['Income This Month'] = 'Log Service Prividers This Month';
$_L['Income This Month1'] = 'Log Service Requestors This Month';
$_L['Income This Month2'] = 'Deivers This Month';
$_L['Expense This Month'] = 'Expense This Month';
$_L['Income n Expense'] = 'Income & Expense';
$_L['Net Worth n Account Balances'] = 'Net Worth & Account Balances';
$_L['Set Goal'] = 'Set Goal';
$_L['Income vs Expense'] = 'Income vs Expense';
$_L['Latest Income'] = 'Latest Income';
$_L['Latest Expense'] = 'Latest Expense';
$_L['Copyright'] = 'Copyright';
$_L['Contacts'] = 'Contacts';
$_L['Message Should be between 5 to 1000 characters'] =
    'Message Should be between 5 to 1000 characters';
$_L['Deleted Successfully'] = 'Deleted Successfully';
$_L['Invalid Email'] = 'Invalid Email';
$_L['Email already exist'] = 'Email already exist';
$_L['Invalid Phone'] = 'Invalid Phone';
$_L['Account Name is required'] = 'Account Name is required';
$_L['Subject is Empty'] = 'Subject is Empty';
$_L['Message is Empty'] = 'Message is Empty';
$_L['Edit Contact'] = 'Edit Contact';
$_L['Full Name'] = 'Full Name';
$_L['Email'] = 'Email';
$_L['Phone'] = 'Phone';
$_L['Address'] = 'Address';
$_L['City'] = 'City';
$_L['State Region'] = 'State/Region';
$_L['ZIP Postal Code'] = 'ZIP/Postal Code';
$_L['Country'] = 'Country';
$_L['Select Country'] = 'Select Country';
$_L['Tags'] = 'Tags';
$_L['Working'] = 'Working';
$_L['are_you_sure'] = 'Are You Sure?';
$_L['Set New Goal for Net Worth'] = 'Set New Goal for Net Worth';
$_L['All Transactions at Date'] = 'All Transactions at Date';
$_L['Total Income'] = 'Total Income';
$_L['Dr'] = '';
$_L['Cr'] = '';
$_L['New Contact Added'] = 'New Contact Added';
$_L['Contact Deleted Successfully'] = 'Contact Deleted Successfully';
$_L['Invoice Deleted Successfully'] = 'Invoice Deleted Successfully';
$_L['Tag Deleted Successfully'] = 'Tag Deleted Successfully';
$_L['TAX Deleted Successfully'] = 'TAX Deleted Successfully';
$_L['Login Successful'] = 'Login Successful';
$_L['Invalid Username or Password'] = 'Invalid Username or Password';
$_L['Failed Login'] = 'Failed Login';
$_L['Check your email to reset Password'] =
    'Check your email to reset Password';
$_L['User Not Found'] = 'User Not Found';
$_L['Invalid Password Reset Key'] = 'Invalid Password Reset Key';
$_L['Activity'] = 'Activity';
$_L['Summary'] = 'Summary';
$_L['Custom Contact Fields'] = 'Custom Contact Fields';
$_L['Account Title'] = 'Account Title';
$_L['Initial Balance'] = 'Initial Balance';
$_L['Financial Balances'] = 'Financial Balances';
$_L['More'] = 'More';
$_L['Contact Notes'] = 'Contact Notes';
$_L['Save'] = 'Save';
$_L['Create Recurring Invoice'] = 'Create Recurring Invoice';
$_L['Create New Invoice'] = 'Create New Invoice';
$_L['Customer'] = 'Customer';
$_L['Select Contact'] = 'Select Contact';
$_L['Or Add New Customer'] = 'Or Add New Customer';
$_L['Invoice Prefix'] = 'Invoice Prefix';
$_L['Repeat Every'] = 'Repeat Every';
$_L['Week'] = 'Week';
$_L['Weeks_2'] = '2 Weeks';
$_L['Month'] = 'Month';
$_L['Months_2'] = '2 Months';
$_L['Months_3'] = '3 Months';
$_L['Months_6'] = '6 Months';
$_L['Year'] = 'Year';
$_L['Years_2'] = '2 Years';
$_L['Years_3'] = '3 Years';
$_L['Invoice Date'] = 'Invoice Date';
$_L['Payment Terms'] = 'Payment Terms';
$_L['Due On Receipt'] = 'Due On Receipt';
$_L['days_3'] = '+3 days';
$_L['days_5'] = '+5 days';
$_L['days_7'] = '+7 days';
$_L['days_10'] = '+10 days';
$_L['days_15'] = '+15 days';
$_L['days_30'] = '+30 days';
$_L['days_45'] = '+45 days';
$_L['days_60'] = '+60 days';
$_L['Sales TAX'] = 'Sales TAX';
$_L['None'] = 'None';
$_L['Discount'] = 'Discount';
$_L['Set Discount'] = 'Set Discount';
$_L['Item Code'] = 'Item Code';
$_L['Item Name'] = 'Item Name';
$_L['Qty'] = 'Qty';
$_L['Price'] = 'Price';
$_L['Add blank Line'] = 'Add blank Line';
$_L['Add Product OR Service'] = 'Add Product OR Service';
$_L['Invoice Terms'] = 'Invoice Terms';
$_L['Save Invoice'] = 'Save Invoice';
$_L['Sub Total'] = 'Sub Total';
$_L['TAX'] = 'TAX';
$_L['TOTAL'] = 'TOTAL';
$_L['Due Date'] = 'Due Date';
$_L['List Products'] = 'List Products';
$_L['List Services'] = 'List Services';
$_L['Sales Price'] = 'Sales Price';
$_L['Item Number'] = 'Item Number';
$_L['Add TAX'] = 'Add TAX';
$_L['Rate'] = 'Rate';
$_L['Back To The List'] = 'Back To The List';
$_L['Add Activity'] = 'Add Activity';
$_L['Post'] = 'Post';
$_L['Account Name'] = 'Account Name';
$_L['Subject'] = 'Subject';
$_L['Send'] = 'Send';
$_L['Onetime'] = 'Onetime';
$_L['Unpaid'] = 'Unpaid';
$_L['Paid'] = 'Paid';
$_L['Cancelled'] = 'Cancelled';
$_L['Manage Recurring Invoices'] = 'Manage Recurring Invoices';
$_L['Add Invoice'] = 'Add Invoice';
$_L['Upload Picture'] = 'Upload Picture';
$_L['Use Gravatar'] = 'Use Gravatar';
$_L['No Image'] = 'No Image';
$_L['Picture'] = 'Picture';
$_L['Facebook Profile'] = 'Facebook Profile';
$_L['Google Plus Profile'] = 'Google Plus Profile';
$_L['Linkedin Profile'] = 'Linkedin Profile';
$_L['Accounting Summary'] = 'Accounting Summary';
$_L['Dr'] = 'Dr.';
$_L['Cr'] = 'Cr.';
$_L['Add Custom Field'] = 'Add Custom Field';
$_L['Field Name'] = 'Field Name';
$_L['Field Type'] = 'Field Type';
$_L['Text Box'] = 'Text Box';
$_L['Drop Down'] = 'Drop Down';
$_L['Text Area'] = 'Text Area';
$_L['Optional Description help'] =
    'Optional Description, will be shown as help block';
$_L['Regular Expression Validation'] = 'Regular Expression Validation String';
$_L['Comma Separated List'] = 'Comma Separated  List for Dropdowns Only';
$_L['Show in View Invoice'] = 'Show in View Invoice?';
$_L['Yes'] = 'Yes';
$_L['No'] = 'No';
$_L['Validation'] = 'Validation';
$_L['Select Options'] = 'Select Options';
$_L['Edit Custom Field'] = 'Edit Custom Field';
$_L['Application Name'] = 'Application Name/ Company Name';
$_L['This Name will be'] =
    'This Name will be shown on the Title, Copyright etc.';
$_L['Theme'] = 'Theme';
$_L['Style'] = 'Style';
$_L['Pay To Address'] = 'Pay To Address';
$_L['You can use html tag'] = 'You can use html tag';
$_L['Invoice Starting'] = 'Invoice Starting';
$_L['Enter to set the next invoice'] =
    'Enter to set the next invoice number, must be greater than Current auto increment value';
$_L['Keep Blank for'] = 'Keep Blank for no change';
$_L['This will replace existing logo'] =
    'This will replace existing logo. You may also change logo by replacing file';
$_L['User Interface'] = 'User Interface';
$_L['Enable Page Loading Animation'] = 'Enable Page Loading Animation?';
$_L['Enable RTL'] = 'Enable RTL?';
$_L['Logo'] = 'Logo';
$_L['Automation'] = 'Automation';
$_L['Security Token'] = 'Security Token';
$_L['Re Generate Key'] = 'Re Generate Key';
$_L['to_enable_automation'] =
    'To enable the automation features to run, make sure you set up a cron job to run once per day. (e.g. 9AM).';
$_L['Create the following Cron Job using GET'] =
    'Create the following Cron Job using GET:';
$_L['Or'] = 'Or';
$_L['Create the following Cron Job using PHP'] =
    'Create the following Cron Job using PHP:';
$_L['Create the following Cron Job using WGET'] =
    'Create the following Cron Job using WGET:';
$_L['Generate Daily Accounting Snapshot'] =
    'Generate Daily Accounting Snapshot';
$_L['Generate Recurring Invoices'] = 'Generate Recurring Invoices';
$_L['Enable Email Notifications'] = 'Enable Email Notifications';
$_L['Save Changes'] = 'Save Changes';
$_L['Edit Categories'] = 'Edit Categories';
$_L['Deleting Categories will'] =
    'Deleting Categories will rename all transactions under this category to Uncategorized';
$_L['Current Password'] = 'Current Password';
$_L['New Password'] = 'New Password';
$_L['Confirm New Password'] = 'Confirm New Password';
$_L['INVOICE'] = 'INVOICE';
$_L['Total Amount'] = 'Total Amount';
$_L['Invoiced To'] = 'Invoiced To';
$_L['Item'] = 'Item';
$_L['Quantity'] = 'Quantity';
$_L['Related Transactions'] = 'Related Transactions';
$_L['Download PDF'] = 'Download PDF';
$_L['Printable Version'] = 'Printable Version';
$_L['Amount Due'] = 'Amount Due';
$_L['Pay Now'] = 'Pay Now';
$_L['Add Deposit'] = 'Add Deposit';
$_L['Choose an'] = 'Choose an';
$_L['Advanced'] = 'Advanced';
$_L['Choose Contact'] = 'Choose Contact';
$_L['Select Payment Method'] = 'Select Payment Method';
$_L['ref_example'] = 'e.g. Transaction ID, Check No.';
$_L['Recent Deposits'] = 'Recent Deposits';
$_L['Custom Fields'] = 'Custom Fields';
$_L['Custom Fields Not Available'] = 'Custom Fields Not Available';
$_L['Total Database Size'] = 'Total Database Size';
$_L['Download Database Backup'] = 'Download Database Backup';
$_L['Table Name'] = 'Table Name';
$_L['Rows'] = 'Rows';
$_L['Size'] = 'Size';
$_L['Edit TAX'] = 'Edit TAX';
$_L['Active'] = 'Active';
$_L['Inactive'] = 'Inactive';
$_L['Send Email Using'] = 'Send Email Using';
$_L['PHP mail Function'] = 'PHP mail() Function';
$_L['SMTP'] = 'SMTP';
$_L['System Email'] = 'System Email';
$_L['All Outgoing Email Will'] =
    'All Outgoing Email Will be sent from This Email Address.';
$_L['SMTP Host'] = 'SMTP Host';
$_L['SMTP Username'] = 'SMTP Username';
$_L['SMTP Password'] = 'SMTP Password';
$_L['SMTP Port'] = 'SMTP Port';
$_L['SMTP Secure'] = 'SMTP Secure';
$_L['TLS'] = 'TLS';
$_L['SSL'] = 'SSL';
$_L['Add Expense'] = 'Add Expense';
$_L['Choose an Account'] = 'Choose an Account';
$_L['Recent Expense'] = 'Recent Expense';
$_L['Manage Categories'] = 'Manage Categories';
$_L['drag_n_drop_help'] =
    'Drag & drop the Items below for Repositioning. Click to Edit.';
$_L['Reset Password'] = 'Reset Password';
$_L['Back To Login'] = 'Back To Login';
$_L['Email Address'] = 'Email Address';
$_L['Related Emails'] = 'Related Emails';
$_L['Invoice'] = 'Invoice';
$_L['Send Email'] = 'Send Email';
$_L['Invoice Created'] = 'Invoice Created';
$_L['Invoice Payment Reminder'] = 'Invoice Payment Reminder';
$_L['Invoice Overdue Notice'] = 'Invoice Overdue Notice';
$_L['Invoice Payment Confirmation'] = 'Invoice Payment Confirmation';
$_L['Invoice Refund Confirmation'] = 'Invoice Refund Confirmation';
$_L['Mark As'] = 'Mark As';
$_L['Partially Paid'] = 'Partially Paid';
$_L['Add Payment'] = 'Add Payment';
$_L['Preview'] = 'Preview';
$_L['PDF'] = 'PDF';
$_L['View PDF'] = 'View PDF';
$_L['Print'] = 'Print';
$_L['Subtotal'] = 'Subtotal';
$_L['Grand Total'] = 'Grand Total';
$_L['Search by Name'] = 'Search by Name';
$_L['Search'] = 'Search';
$_L['Add New Contact'] = 'Add New Contact';
$_L['Filter by Tags'] = 'Filter by Tags';
$_L['n_a'] = 'n/a';
$_L['Records'] = 'Records';
$_L['List Invoices'] = 'List Invoices';
$_L['Add Recurring Invoice'] = 'Add Recurring Invoice';
$_L['Due'] = 'Due';
$_L['Next Invoice'] = 'Next Invoice';
$_L['Stop Recurring'] = 'Stop Recurring';
$_L['Add Tax'] = 'Add Tax';
$_L['Tax Rate'] = 'Tax Rate';
$_L['Default Country'] = 'Default Country';
$_L['Date Format'] = 'Date Format';
$_L['Currency Format'] = 'Currency Format';
$_L['Currency Code'] = 'Currency Code';
$_L['Keep it blank if currency code'] =
    'Keep it blank if you do not want to show currency code';
$_L['Charset n Collation'] = 'Charset & Collation';
$_L['Set Charset n Collation'] = 'Set Charset & Collation For Database Tables';
$_L['Sign in'] = 'Sign in';
$_L['Forgot password'] = 'Forgot password ?';
$_L['Edit Transaction'] = 'Edit Transaction';
$_L['Add User'] = 'Add User';
$_L['Access Level'] = 'Access Level';
$_L['Full Access'] = 'Full Access';
$_L['Loading Users'] = 'Loading Users';
$_L['Add Payee'] = 'Add Payee';
$_L['Manage Payees'] = 'Manage Payees';
$_L['Edit Payee'] = 'Edit Payee';
$_L['Edit Payer'] = 'Edit Payer';
$_L['Add Payer'] = 'Add Payer';
$_L['Manage Payers'] = 'Manage Payers';
$_L['Reorder Payment Gateways'] = 'Reorder Payment Gateways Position';
$_L['Gateway Name'] = 'Gateway Name';
$_L['Setting Name'] = 'Setting Name';
$_L['Value'] = 'Value';
$_L['Reorder'] = 'Reorder';
$_L['Positions'] = 'Positions';
$_L['Settings Name'] = 'Settings Name';
$_L['Custom Param 1'] = 'Custom Param 1';
$_L['Conversion Rate'] = 'Conversion Rate';
$_L['Custom Param 2'] = 'Custom Param 2';
$_L['Custom Param 3'] = 'Custom Param 3';
$_L['Custom Param 4'] = 'Custom Param 4';
$_L['Custom Param 5'] = 'Custom Param 5';
$_L['Add Payment Methods'] = 'Add Payment Methods';
$_L['Manage Payment Methods'] = 'Manage Payment Methods';
$_L['Edit Payment Methods'] = 'Edit Payment Methods';
$_L['Click Here to Print'] = 'Click Here to Print';
$_L['Add Product'] = 'Add Product';
$_L['Add Service'] = 'Add Service';
$_L['List'] = 'List';
$_L['Expense Summary'] = 'Expense Summary';
$_L['Total Expense This Month'] = 'Total Expense This Month';
$_L['Total Expense This Week'] = 'Total Expense This Week';
$_L['Total Expense Last 30 days'] = 'Total Expense Last 30 days';
$_L['Last 20 deposit Expense'] = 'Last 20 deposit/ Expense';
$_L['Dr.'] = 'Dr.';
$_L['Monthly Expense Graph'] = 'Monthly Expense Graph';
$_L['Income Summary'] = 'Income Summary';
$_L['Total Income This Month'] = 'Total Income This Month';
$_L['Total Income This Week'] = 'Total Income This Week';
$_L['Total Income Last 30 days'] = 'Total Income Last 30 days';
$_L['Last 20 deposit Income'] = 'Last 20 deposit/ Income';
$_L['Monthly Income Graph'] = 'Monthly Income Graph';
$_L['Reports Income Vs Expense'] = 'Reports- Income Vs Expense';
$_L['Income minus Expense'] = 'Income - Expense';
$_L['Income Vs Expense This Year'] = 'Income Vs Expense This Year';
$_L['View Statement'] = 'View Statement';
$_L['From Date'] = 'From Date';
$_L['To Date'] = 'To Date';
$_L['Export for Print'] = 'Export for Print';
$_L['Export to PDF'] = 'Export to PDF';
$_L['Tag'] = 'Tag';
$_L['New Transfer'] = 'New Transfer';
$_L['Recent Transfers'] = 'Recent Transfers';
$_L['Add New User'] = 'Add New User';
$_L['User'] = 'User';
$_L['Full Administrator'] = 'Full Administrator';
$_L['Choose User Type'] =
    'Choose User Type Employee to disable Settings access';
$_L['Confirm Password'] = 'Confirm Password';
$_L['Edit User'] = 'Edit User';
$_L['Clear Old Data'] = 'Clear Old Data';
$_L['UID'] = 'UID';
$_L['IP'] = 'IP';
$_L['ID'] = 'ID';
$_L['Total Email Sent'] = 'Total Email Sent';
$_L['Sent To'] = 'Sent To';
$_L['Back To Emails'] = 'Back To Emails';
$_L['Settings Saved Successfully'] = 'Settings Saved Successfully';
$_L['New Goal has been set'] = 'New Goal has been set';
$_L['Choose the Traget Account'] = 'Please choose the Traget Account';
$_L['See All Activity'] = 'See All Activity';

/*
 * @ From V 2.2.0
 */

$_L['Item Added Successfully'] = 'Item Added Successfully';
$_L['Password changed successfully'] =
    'Password changed successfully, Please login again';
$_L['Data Updated'] = 'Data Updated!';
$_L['Transaction Added Successfully'] = 'Transaction Added Successfully';
$_L['Invalid Number'] = 'Invalid Number';
$_L['Logs has been deleted'] = 'Logs older than 30 days has been deleted';
$_L['Password Reset Key Expired'] = 'Password Reset Key Expired';
$_L['Payment Cancelled'] = 'Payment Cancelled';
$_L['Custom Field Deleted Successfully'] = 'Custom Field Deleted Successfully';
$_L['Plugin Not Found'] = 'Plugin Not Found';
$_L['You do not have permission'] =
    'You do not have permission to access this page';
$_L['disabled_in_demo'] = 'This Option is disabled in the Demo Mode';
$_L['All Fields are Required'] = 'All Fields are Required';
$_L['Invalid System Email'] = 'Invalid System Email';
$_L['smtp_fields_error'] = 'SMTP Username, Password and Port is required';
$_L['Charset Saved Successfully'] = 'Charset Saved Successfully';
$_L['password_length_error'] = 'New Password must be 6 to 14 character';
$_L['Both Password should be same'] = 'Both Password should be same';
$_L['Incorrect Current Password'] = 'Incorrect Current Password';
$_L['Invalid Logo File'] = 'Invalid Logo File';
$_L['Invalid TAX Rate'] = 'Invalid TAX Rate';
$_L['New TAX Added'] = 'New TAX Added';
$_L['TAX Not Found'] = 'TAX Not Found';
$_L['cron_new_key'] =
    'New Key Generated. Please Make Sure to Update The CRON Jobs.';
$_L['cron_notification'] =
    'Please Use a valid Email Address to enable Notification';
$_L['Select'] = 'Select';
$_L['Close'] = 'Close';
$_L['Update'] = 'Update';
$_L['OK'] = 'OK';
$_L['Terms'] = 'Terms';
$_L['PDF Font'] = 'PDF Font';
$_L['pdf_font_help_default'] = 'Default [Faster PDF Creation with Less Memory]';
$_L['pdf_font_help_helvetica'] = 'Helvetica'; #Font name
$_L['pdf_font_help_dejavusanscondensed'] =
    'dejavusanscondensed [Embed fonts with supports UTF8]'; # dejavusanscondensed is font name, you can either translate this or you may ignore this word from this string
$_L['Invoice Total'] = 'Invoice Total';
$_L['Total Paid'] = 'Total Paid';
$_L['Unique Invoice URL'] = 'Unique Invoice URL';
$_L['Company Name'] = 'Company Name';
$_L['ATTN'] = 'ATTN'; # The short of Atention, used in invoicing
/*
 * @ From V 2.3.0
 */

$_L['Payment Successful'] = 'Payment Successful';
$_L['Plugins'] = 'Plugins';

/*
 * @ From V 2.4.0
 */

$_L['Installing Plugin'] = 'Installing Plugin';
$_L['Uninstalling Plugin'] = 'Uninstalling Plugin';
$_L['Activating Plugin'] = 'Activating Plugin';
$_L['Deactivating Plugin'] = 'Deactivating Plugin';
$_L['Deleting Plugin'] = 'Deleting Plugin';
$_L['Upload Plugin'] = 'Upload Plugin';
$_L['Unzipping'] = 'Unzipping';
$_L['Plugin Added'] = 'Plugin Added';
$_L['No Plugins Available'] = 'No Plugins Available';

$_L['Quotes'] = 'Quotes';
$_L['Quote'] = 'Quote';

$_L['Choose Features'] = 'Choose Features';
$_L['Accounting'] = 'Accounting';
$_L['Invoicing'] = 'Invoicing';
$_L['Quotes'] = 'Quotes';
$_L['Enable Client Dashboard'] = 'Enable Client Dashboard / Portal';
$_L['quote_alias'] = 'Create New Quote / Proposal / Estimate';
$_L['Date Created'] = 'Date Created';
$_L['Expiry Date'] = 'Expiry Date';
$_L['Stage'] = 'Stage';
$_L['Draft'] = 'Draft';
$_L['Delivered'] = 'Delivered';
$_L['Accepted'] = 'Accepted';
$_L['On Hold'] = 'On Hold';
$_L['Lost'] = 'Lost';
$_L['Dead'] = 'Dead';
$_L['Reports by Category'] = 'Reports by Category';
//Month Names
$_L['January'] = 'January';
$_L['February'] = 'February';
$_L['March'] = 'March';
$_L['April'] = 'April';
$_L['May'] = 'May';
$_L['June'] = 'June';
$_L['July'] = 'July';
$_L['August'] = 'August';
$_L['September'] = 'September';
$_L['October'] = 'October';
$_L['November'] = 'November';
$_L['December'] = 'December';

$_L['Discount Type'] = 'Discount Type';
$_L['Percentage'] = 'Percentage';
$_L['Fixed Amount'] = 'Fixed Amount';
$_L['Page'] = 'Page';
$_L['of'] = 'of';
$_L['Loading'] = 'Loading';
$_L['Payment'] = 'Payment';
$_L['Recipient'] = 'Recipient';
$_L['Proposal Text'] = 'Proposal Text';
$_L['quote_help_top'] = 'Displayed at the Top of the Quote';
$_L['quote_help_footer'] = 'Displayed as a Footer to the Quote';
$_L['Customer Notes'] = 'Customer Notes';
$_L['Save n Close'] = 'Save & Close';
$_L['Quote Created'] = 'Quote Created';
$_L['Convert to Invoice'] = 'Convert to Invoice';
$_L['Quote Prefix'] = 'Quote Prefix';
$_L['quote_number_help'] =
    'Keep it Blank to Generate Quote Number Automatically';
$_L['invoice_number_help'] =
    'Keep it Blank to Generate Invoice Number Automatically';

$_L['Public Key'] = 'Public Key';
$_L['Private Key'] = 'Private Key';
$_L['Default Account'] = 'Default Account';
$_L['live or sandbox'] = 'live or sandbox';

$_L['plugin_drop_help'] = 'Drop Plugin here or click to upload';
$_L['plugin_upload_help'] = '(Upload Plugin zip file)';
$_L['Admin'] = 'Admin';
$_L['Message Body'] = 'Message Body';

$_L['Invoice:Invoice Created'] = 'Invoice - Invoice Created';
$_L['Admin:Password Change Request'] = 'Admin - Password Change Request';
$_L['Admin:New Password'] = 'Admin - New Password';
$_L['Invoice:Invoice Payment Reminder'] = 'Invoice - Invoice Payment Reminder';
$_L['Invoice:Invoice Overdue Notice'] = 'Invoice - Invoice Overdue Notice';
$_L['Invoice:Invoice Payment Confirmation'] =
    'Invoice - Invoice Payment Confirmation';
$_L['Invoice:Invoice Refund Confirmation'] =
    'Invoice - Invoice Refund Confirmation';
$_L['Quote:Quote Created'] = 'Quote - Quote Created';
$_L['Send Notifications To'] = 'Send Notifications To';
$_L['No results found'] = 'No results found';
$_L['Quote Deleted Successfully'] = 'Quote Deleted Successfully';
$_L['Create New Quote'] = 'Create New Quote';

# V3.0.0

$_L['notice_email_as_username'] =
    'Please use a valid Email address as Username';
$_L['API'] = 'API';
$_L['API Access'] = 'API Access';
$_L['Add API Access'] = 'Add API Access';
$_L['Label'] = 'Label';
$_L['API Key'] = 'API Key';
$_L['Regenerate'] = 'Regenerate';
$_L['Application URL'] = 'Application URL';

# V3.1.0
$_L['API Access Added'] = 'API Access Added';
$_L['select_a_contact'] = 'Please select a Contact';
$_L['at_least_one_item_required'] = 'At least one item is required';
$_L['Subject is Required'] = 'Subject is Required';
$_L['Unique Quote URL'] = 'Unique Quote URL';

# V3.3.0
$_L['Default Invoice Terms'] = 'Default Invoice Terms';
$_L['Additional Settings'] = 'Additional Settings';
$_L['cron_invoice_created'] = 'Automatically email recurring invoices';

# V3.4.0

$_L['Invoice Creation Method'] = 'Invoice Creation Method';
$_L['Default'] = 'Default';
$_L['V2'] = 'V2';

# V 3.6.0

$_L['CRON Log'] = 'CRON Log';
$_L['Message'] = 'Message';
$_L['Recent Invoices'] = 'Recent Invoices';

# V 3.7.0

# V 4.0.0

$_L['About'] = 'About';
$_L['Or Install from URL'] = 'Or Install from URL';
$_L['Fold Sidebar Default'] = 'Fold Sidebar by Default ?';
$_L['Hide Footer Copyright'] = 'Hide Footer Copyright ?';
$_L['Filter'] = 'Filter';
$_L['Back'] = 'Back';
$_L['Account Number'] = 'Account Number';
$_L['Contact Person'] = 'Contact Person';
$_L['Internet Banking URL'] = 'Internet Banking URL';

# V 4.1.0

$_L['Cc'] = 'Cc';
$_L['Bcc'] = 'Bcc';
$_L['Mode'] = 'Mode';
$_L['Live'] = 'Live';
$_L['Sandbox'] = 'Sandbox';
$_L['Drop CSV File Here'] = 'Drop CSV File Here';
$_L['Or Click to Upload'] = 'Or Click to Upload';
$_L['Importing'] = 'Importing';
$_L['Import Contacts'] = 'Import Contacts';
$_L['Download Sample File'] = 'Download Sample File';


$_L['Groups0'] = 'Trucks Registration';
$_L['Add New Group'] = 'Add New Group';
$_L['Group Name'] = 'Group Name';
$_L['Group Deleted Successfully'] = 'Group Deleted Successfully';
$_L['Welcome Email'] = 'Welcome Email';
$_L['Client:Client Signup Email'] = 'Client Signup Email';
$_L['Send Client Signup Email'] = 'Set Yes to send Client Signup Email.';
$_L['Profile'] = 'Profile';
$_L['Download'] = 'Download';
$_L['Legacy'] = 'Legacy';
$_L['New'] = 'New';
$_L['Default Landing Page'] = 'Default Landing Page';
$_L['Admin Login'] = 'Admin Login';
$_L['Client Login'] = 'Client Login';
$_L['Recent Quotes'] = 'Recent Quotes';
$_L['Recent Transactions'] = 'Recent Transactions';

# V 4.2.0

$_L['URL Rewrite'] = 'URL Rewrite';
$_L['Currency Symbol'] = 'Currency Symbol';
$_L['Home Currency'] = 'Home Currency';
$_L['Currency Symbol Position'] = 'Currency Symbol Position';
$_L['Left'] = 'Left';
$_L['Right'] = 'Right';
$_L['Currency Decimal Digits'] = 'Currency Decimal Digits';
$_L['Thousand Separator Placement'] = 'Thousand Separator Placement';

# V 4.2.1

$_L['Or Cancel'] = 'Or Cancel';
$_L['Send Bcc to Admin'] = 'Send Bcc to Admin? Click Here.';
$_L['Attach PDF'] = 'Attach PDF?';

# v 4.4.0

$_L['Cash Flow'] = 'Cash Flow';

//Month Names short
$_L['Jan'] = 'Jan';
$_L['Feb'] = 'Feb';
$_L['Mar'] = 'Mar';
$_L['Apr'] = 'Apr';
$_L['May'] = 'May';
$_L['Jun'] = 'Jun';
$_L['Jul'] = 'Jul';
$_L['Aug'] = 'Aug';
$_L['Sep'] = 'Sep';
$_L['Oct'] = 'Oct';
$_L['Nov'] = 'Nov';
$_L['Dec'] = 'Dec';

$_L['Last 12 Months'] = 'Last 12 Months';
$_L['Data View'] = 'Data View';
$_L['Refresh'] = 'Refresh';
$_L['Reset'] = 'Reset';
$_L['Save as Image'] = 'Save as Image';
$_L['Click to Save'] = 'Click to Save';
$_L['Average'] = 'Average';
$_L['Line'] = 'Line';
$_L['Bar'] = 'Bar';
$_L['Net Worth'] = 'Logistic Service Provider';
$_L['Net Worth1'] = 'Logistic Service Requestor';
$_L['Net Worth2'] = 'Drivers';

# v 4.5.0

$_L['Check for Update'] = 'Check for Update';
$_L['Response'] = 'Response';
$_L['Site Key'] = 'Site Key';
$_L['Secret Key'] = 'Secret Key';
$_L['Enable Recaptcha'] = 'Enable reCAPTCHA';
$_L['Recaptcha'] = 'reCAPTCHA';
$_L['Recaptcha Verification Failed'] =
    'Please verify that you are not a robot.';
$_L['Client Portal Custom Scripts'] = 'Client Portal Custom Scripts';
$_L['Header Scripts'] = 'Header Scripts';
$_L['Footer Scripts'] = 'Footer Scripts';

# Build 4505

$_L['Received'] = 'Received';

# Build 4520

$_L['System Status'] = 'System Status';
$_L['Application Environment'] = 'Application Environment';
$_L['Server Environment'] = 'Server Environment';
$_L['Integration Code'] = 'Integration Code';
$_L['Client Registration'] = 'Client Registration';
$_L['Register'] = 'Register';
$_L['Notes'] = 'Notes';
$_L['Quick Notes'] = 'Quick Notes';
$_L['Whats on your mind'] = 'What\'s on your mind?';
$_L['Team'] = 'Team';
$_L['Last Activity'] = 'Last Activity';
$_L['Content Animation'] = 'Content Animation';

# Build 4530

$_L['Appearance'] = 'Appearance';
$_L['Customize'] = 'Customize';
$_L['Editor'] = 'Editor';
$_L['Language Editor'] = 'Language Editor';
$_L['Themes'] = 'Themes';
$_L['Select File to Edit'] = 'Select File to Edit';
$_L['File'] = 'File';
$_L['Language File'] = 'Language File';
$_L['Invoice Layout Print'] = 'Invoice Layout: Print';
$_L['Invoice Layout PDF'] = 'Invoice Layout: PDF';
$_L['Please Choose a File'] = 'Please Choose a File';

# Build 4540

$_L['Profit'] = 'Profit';
$_L['Loss'] = 'Loss';
$_L['Revenue'] = 'Revenue';
$_L['Outstanding'] = 'Outstanding';

# Build 4550

$_L['Payments'] = 'Payments';
$_L['Transaction ID'] = 'Transaction ID';

$_L['Customers'] = 'log services providers';
$_L['Customers1'] = 'log services requestors';
$_L['Companies'] = 'Companies';
$_L['Currencies'] = 'Currencies';
$_L['Permission'] = 'Permission';
$_L['Staff'] = 'Staff';
$_L['Roles'] = 'Roles';
$_L['New Role'] = 'New Role';
$_L['Role name is required'] = 'Role name is required';
$_L['Tasks'] = 'Tasks';
$_L['Calendar'] = 'Calendar';
$_L['Leads'] = 'Leads';
$_L['Orders'] = 'Make a Trade';
$_L['Currency'] = 'Currency';
$_L['New Currency'] = 'New Currency';
$_L['Base Conversion Rate'] = 'Base Conversion Rate';
$_L['Currency Example'] = 'Currency ISO Code, eg. USD, GBP, INR etc...';
$_L['Make Base Currency'] = 'Make Base Currency';
$_L['Base Currency'] = 'Base Currency';
$_L['New Company'] = 'New Company';
$_L['URL'] = 'URL';
$_L['Logo URL'] = 'Logo URL';
$_L['Company Name is required'] = 'Company Name is required.';
$_L['Event Name'] = 'Event Name';
$_L['Priority'] = 'Priority';
$_L['Owner'] = 'Owner';
$_L['Start Date'] = 'Start Date';
$_L['End Date'] = 'End Date';
$_L['Start Time'] = 'Start Time';
$_L['End Time'] = 'End Time';
$_L['All day event'] = 'All day event';
$_L['Related Contacts'] = 'Related Contacts';
$_L['Add Event'] = 'Add Event';
$_L['Color'] = 'Color';
$_L['Image'] = 'Image';
$_L['Create'] = 'Create';
$_L['Avatar'] = 'Avatar';
$_L['Attach File'] = 'Attach File';
$_L['Drop File Here'] = 'Drop File Here';
$_L['Click to Upload'] = 'Or Click to Upload';

# Build 4580
$_L['Import'] = 'Import';
$_L['Export'] = 'Export';
$_L['Phone number already exist'] = 'Phone number already exist.';

# Build 4590
$_L['Favicon'] = 'Favicon';
$_L['Upload'] = 'Upload';
$_L['Remember me'] = 'Keep me signed in';

# Build 4591

$_L['Accept'] = 'Accept';
$_L['Decline'] = 'Decline';

# Build 4592

$_L['Terminal'] = 'Terminal';
$_L['Customers View Mode'] = 'Customers View Mode'; // Customers View Mode in User Interface [ Table / Card / Search ]
$_L['Table'] = 'Table';
$_L['Card'] = 'Card';

# Build 4593

$_L['Your last login was'] = 'Your last login was';

# Build 4596

$_L['Documents'] = 'Documents';
$_L['List All Orders'] = 'List All Trades';
$_L['Add New Order'] = 'Add New Trade';
$_L['Order'] = 'Order';
$_L['Product_Service'] = 'Product/Service';
$_L['Billing Cycle'] = 'Billing Cycle';
$_L['Free'] = 'Free';
$_L['One Time'] = 'One Time';
$_L['Monthly'] = 'Monthly';
$_L['Quarterly'] = 'Quarterly';
$_L['Semi-Annually'] = 'Semi-Annually';
$_L['Annually'] = 'Annually';
$_L['Biennially'] = 'Biennially';
$_L['Triennially'] = 'Triennially';
$_L['Pending'] = 'Pending';
$_L['Generate Invoice'] = 'Generate Invoice';
$_L['Item Not Found'] = 'Item Not Found';
$_L['Available Module for this Order'] = 'Available Module for this Order';
$_L['Order Number'] = 'Order Number';
$_L['New Document'] = 'New Document';
$_L['Title'] = 'Title'; # Document Name / Title
$_L['Server Config'] = 'Server Config';
$_L['Upload Maximum Size'] = 'Upload Maximum Size';
$_L['POST Maximum Size'] = 'POST Maximum Size';
$_L['Uploaded Successfully'] = 'Uploaded Successfully';
$_L['Secure Download Link'] = 'Secure Download Link';
$_L['Files'] = 'Files';
$_L['Assign File'] = 'Assign File';
$_L['Activation Message'] = 'Activation Message';
$_L['Email Sent'] = 'Email Sent';
$_L['Downloads'] = 'Downloads';

# Build 4597

$_L['Create Auto Login URL'] = 'Create Auto Login URL';
$_L['Created Successfully'] = 'Created Successfully';
$_L['Auto Login URL'] = 'Auto Login URL';
$_L['Login As Customer'] = 'Login As Customer';
$_L['Revoke Auto Login'] = 'Revoke Auto Login';
$_L['Re Generate URL'] = 'Re Generate URL';

# Build 4601

$_L['Contact'] = 'Contact';
$_L['All'] = 'All';
$_L['Date Range'] = 'Date Range';
$_L['Available for all Customers'] = 'Available for all Customers';
$_L['Proof Of Payment'] = 'Proof Of Payment';

# Build 4602

$_L['My Orders'] = 'My Trades';
$_L['Place New Order'] = 'Place New Order';
$_L['Cost Price'] = 'Cost Price';
$_L['Inventory To Add Subtract'] = 'Inventory To Add/Subtract';
$_L['Unit'] = 'Unit';
$_L['Units'] = 'Units';
$_L['Units of measurement'] = 'Units of measurement';
$_L['Create New'] = 'Create New';
$_L['Reference'] = 'Reference';
$_L['Conversion Factor'] = 'Conversion Factor';
$_L['SKU'] = 'SKU';
$_L['Weight'] = 'Weight';
$_L['Show quantity as'] = 'Show quantity as';
$_L['New Lead'] = 'New Lead';
$_L['Import Leads'] = 'Import Leads';
$_L['Source'] = 'Source';
$_L['Salutation'] = 'Salutation';
$_L['First Name'] = 'First Name';
$_L['Middle Name'] = 'Middle Name';
$_L['Last Name'] = 'Last Name';
$_L['Industry'] = 'Industry';
$_L['No. of Employees'] = 'No. of Employees';
$_L['Public'] = 'Public';
$_L['Company'] = 'Company';
//for company address  company=company address
$_L['company'] = 'Company address';
$_L['Street'] = 'Street';
$_L['Memo'] = 'Memo'; // Description
$_L['Convert to Customer'] = 'Convert to Customer';
$_L['Buy Now'] = 'Buy Now';
$_L['Store'] = 'Store';
$_L['Add to Cart'] = 'Add to Cart';
$_L['Copy'] = 'Copy';
$_L['Unknown'] = 'Unknown';
$_L['Access Log'] = 'Access Log';
$_L['Browser'] = 'Browser';
$_L['Time'] = 'Time';
$_L['Invoice Access Log'] = 'Invoice Access Log';
$_L['Clone'] = 'Clone';
$_L['Cloned successfully'] = 'Cloned successfully';
$_L['Media'] = 'Media';
$_L['Inventory'] = 'Inventory';
$_L['Available'] = 'Available';
$_L['Published'] = 'Published';
$_L['No Data Available'] = 'No Data Available';
$_L['Send SMS'] = 'Send SMS';
$_L['Call'] = 'Call'; // Phone Call
$_L['Saved Successfully'] = 'Saved Successfully';
$_L['System'] = 'System';
$_L['Custom'] = 'Custom';
$_L['Choose from Template'] = 'Choose from Template';
$_L['Add New Template'] = 'Add New Template';
$_L['Assign to Group'] = 'Assign to Group';
$_L['Select Group'] = 'Select Group';
$_L['Empty'] = 'Empty';
$_L['Related To'] = 'Related To';
$_L['Add New'] = 'Add New';
$_L['Add Fund'] = 'Add Fund';
$_L['Back to Client Area'] = 'Back to Client Area';
$_L['Manual Credit'] = 'Manual Credit';
$_L['Log'] = 'Log';
$_L['Client'] = 'Client';
$_L['All Data'] = 'All Data';

# 4663
$_L['Sales target'] = 'Sales target'; # Sales target for specific month
$_L['Invoice issued'] = 'Invoice issued';
//fname=First Name lname=Name
$_L['lname'] = 'Name';
$_L['fname'] = 'First Name';
//Number of trucks
$_L['trucks'] = 'Number of trucks';
//Country1=Transportation countries
$_L['Country1'] = 'Transportation countries';
//'Administrative file=Administrative file
$_L['Administrative file'] = 'Administrative file';
//truck files
$_L['trucks files'] = 'Trucks files';
//transport license
$_L['Transport License'] = 'Transport License';

$_L['Groups'] = 'Groups';
$_L['Groups1'] = 'Groups1';
$_L['Groups2'] = 'Groups2';
//Companies1=transportGoods
$_L['Companies0'] = 'Purchase Construction Material';
$_L['Companies1'] = 'Transport Goods';
$_L['Companies2'] = 'Rental Heavy Machine';
$_L['Companies3'] = 'Driver';
$_L['nCompanies3'] = 'New Driver';
$_L['Companies4'] = 'Rental Heavy Machine4';
$_L['Companies5'] = 'Rental Heavy Machine5';
//
$_L['New transport Goods'] = 'New Equipment';
$_L['Rental of Agricultural Equipment'] = 'Rental of Agricultural Equipment';
$_L['Other Types'] = 'Other Types';
$_L['Types of goods'] = 'Types of goods';
$_L['Estimated value'] = 'Estimated value';
$_L['Weight'] = 'Weight';
$_L['Origin country'] = 'Origin country';
$_L['Destination country'] = 'Destination country';
$_L['Pickup location'] = 'Pickup location';
$_L['Delivery location'] = 'Delivery location';
$_L['Type of Machine'] = 'Type of Machine';

$_L['Rental start date'] = 'Rental start date';
$_L['Rental end date'] = 'Rental end date';
$_L['Number of rental day'] = 'Number of rental days';
$_L['Proposed price per hours'] = 'Proposed price per hour';
$_L['Number of working hours'] = 'Number of working hours';
$_L['Rentalheavymachine'] = 'Rental heavy machine';
$_L['picture 01'] = 'Picture 01';
$_L['picture 02'] = 'Picture 02';
$_L['Delivery time'] = 'Delivery time';
$_L['Types of materials'] = 'Types of materials';
$_L['picture 03'] = 'Picture 03';
$_L['picture 04'] = 'Picture 04';
//$_L['picture 04'] = 'Picture 04 *';
$_L['Attach File6'] = 'Attach File';
$_L['Add New Rentalheavymachine'] = 'Add New Rentalheavymachine';

$_L['name'] = 'Name *';
$_L['N° phone'] = 'N° phone';
$_L['N° permit'] = 'N° permit';
$_L['Permit Category'] = 'Permit Category';
$_L['Expiry Date'] = 'Expiry Date';
$_L['Picture of truck'] = 'Picture of Engine';
$_L['location'] = 'location';
$_L['type of material'] = 'type of Engine';
$_L['Picture of Permit'] = 'Picture of Permit';
$_L['Purchase packaging materials'] = 'Purchase packaging materials';
$_L['New packaging materials'] = 'New packaging material';
$_L['Type of packaging material'] = 'Type of packaging material ';
$_L['Size'] = 'Size';
$_L['Weight'] = 'Weight';
$_L['Estimated value'] = 'Estimated value';
$_L['Destination country'] = 'Destination country';
$_L['Delivery location'] = 'Delivery location';
$_L['Quantity'] = 'Quantity';
$_L['Informations'] = 'Informations';
$_L['ID'] = 'ID';
$_L['LSP Company'] = 'LSP Company';
$_L['Truck Immatriculation'] = 'Truck Immatriculation';
$_L['Type of truck'] = 'Type of truck';
$_L["truck's Picture"] = "Truck's Picture";
$_L['Truck insurance'] = 'Truck insurance';
$_L['Truck Insurance start date'] = 'Truck Insurance start date';
$_L['Truck Insurance expiration date'] = 'Truck Insurance expiration date';
$_L['Truck patent'] = 'Truck patent';
$_L['Truck registration document'] = 'Truck registration document';
$_L['New Company2'] = 'New equipment';
$_L['Truck availability'] = 'Truck availability';


$_L['LSP Company*'] = 'LSP Company';
$_L['Truck Immatriculation*'] = 'Truck Immatriculation';
$_L['Type of truck*'] = 'Type of truck';
$_L["truck's Picture*"] = "Truck's Picture";
$_L['Truck insurance*'] = 'Truck insurance';
$_L['Truck Insurance start date*'] = 'Truck Insurance start date';
$_L['Truck Insurance expiration date*'] = 'Truck Insurance expiration date';
$_L['Truck patent*'] = 'Truck patent';
$_L['Truck registration document*'] = 'Truck registration document';
$_L['New Company2'] = 'New Equipment';
$_L['Truck availability*'] = 'Truck availability';
$_L['Trucks Registration'] = 'Trucks Registration';
$_L['Submitlsr'] = 'Submit Transport Request';
$_L['New Submitlsr'] = 'New Transport Request';
$_L['Selection of LSR'] = 'Selection of LSR';
$_L['Types of goods'] = 'Types of goods';
$_L['Estimated value (XAF)'] = 'Estimated value (XAF)';
$_L['Weight (Kg)'] = 'Weight (Kg)';
$_L['Origin Country'] = 'Origin Country';
$_L['Destination country'] = 'Destination country';
$_L['Pick-up Location'] = 'Pick-up Location';
$_L['Delivery Location'] = 'Delivery Location';
$_L['Transit'] = 'Transit';
$_L['Loading Services'] = 'Loading Services';
$_L['Off-loading Service'] = 'Off-loading Service';
$_L['Bill of lading'] = 'Bill of lading';
$_L['Loading Date'] = 'Loading Date ';
$_L['Recipient name'] = 'Recipient name';
$_L['Telephone Number'] = 'Telephone Number';
$_L['Observations'] = 'Observations';
$_L['transport insurance'] = 'transport insurance';
$_L['cPhone'] = 'Company Phone';
$_L['Types of vehicules'] = 'Types of Equipment ';
$_L['Add New LSR'] = 'Add New LSR';
$_L['New LSR'] = 'New LSR';
$_L['Add New LSP'] = 'Add New LSP';
$_L['New LSR'] = 'New LSR';
$_L['Add New material'] = 'Add New Material';
$_L['Purchaseconstructionmaterial'] = 'Purchase Construction Material';
$_L['Rental_Heavy_Machine'] = 'Rental Heavy Machine';
$_L['Purchase Parkaging Material'] = 'Purchase Parkaging Material';
$_L['Submitlsr'] = 'Submit Transport Request';
$_L['Trucks Registration'] = 'Trucks Registration';
$_L['Driver'] = 'Driver';
$_L['LSR'] = 'LSR';
$_L['Rental of Agricultural Equipment'] = 'Rental of Agricultural Equipment';

$_L['Choise the register'] = 'Choise the register';
$_L['List Customers2'] = 'List Drivers';
$_L['Road Worthiness'] = 'Road Worthiness';
$_L['Do you need tracking ?'] = 'Do you need tracking ?';
$_L['Tracking'] = 'Tracking';

#### ---------------------- custom ------------------###
$_L['trades'] = 'Trades';
$_L['Trades'] = 'Trades';
$_L['Add New Trade'] = 'Add New Trade';
$_L['List Trucks Registration'] = 'List Trucks Registration';
