<?php
use Illuminate\Database\Eloquent\Model;

class ContactGroup1 extends Model
{
    protected $table = 'crm_groups1';
    public $timestamps = false;
}