<?php
use Illuminate\Database\Eloquent\Model;

class Contact2 extends Model
{
    protected $table = 'crm_accounts2';
}