<?php
use Illuminate\Database\Eloquent\Model;

class Company5 extends Model
{
    protected $table = 'crm_accounts';
}