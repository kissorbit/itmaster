<?php
use Illuminate\Database\Eloquent\Model;

class Contact1 extends Model
{
    protected $table = 'crm_accounts_1';
}