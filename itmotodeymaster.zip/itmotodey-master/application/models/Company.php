<?php
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $table = 'sys_companies';
}