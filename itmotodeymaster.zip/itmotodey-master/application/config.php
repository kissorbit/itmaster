<?php
$db_host	    = 'localhost';
$db_user        = 'root';
$db_password	= '';
$db_name	    = 'iBilling';
define('APP_URL', 'http://itmotodey.test');
$_app_stage = 'live'; // You can set this variable Live to Dev to enable ibilling Debug
