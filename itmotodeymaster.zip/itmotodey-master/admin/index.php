<?php
header('location: ../?ng=login/where/');