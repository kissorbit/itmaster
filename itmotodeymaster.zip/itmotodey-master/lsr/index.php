<?php
header('location: ../?ng=lsr/where/');
