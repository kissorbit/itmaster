<?php
define('APP_RUN', true);
require 'application/app.php';
